export { default } from './Label';
