import axios from 'axios';
import Cookies from 'js-cookie';

const API_BASE_URL = 'https://localhost:7196';
// api.js
const axiosInstance = axios.create({
    headers: {
        'Content-Type': 'application/json',

        // Add any other headers here, like Authorization for authentication
    },
});

export const ApiService = {
    async logout() {
        try {
            Cookies.remove('token');
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Network response was not ok');
        }
    },
    async login(endpoint, data) {
        try {
            const response = await axiosInstance.post(endpoint, data);
            let token = response.data;
            Cookies.set('token', token, { expires: 7 });
            axiosInstance.defaults.headers.common['Authorization'] = `Bearer ${token}`;
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Network response was not ok');
        }
    },
    async get(endpoint) {
        try {
            let token = Cookies.get('token');
            axiosInstance.defaults.headers.common['Authorization'] = `Bearer ${token}`;
            const response = await axiosInstance.get(endpoint);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Network response was not ok');
        }
    },

    async post(endpoint, data) {
        try {
            const response = await axiosInstance.post(endpoint, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Network response was not ok');
        }
    },

    async put(endpoint, data) {
        try {
            const response = await axiosInstance.put(endpoint, data);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Network response was not ok');
        }
    },

    async delete(endpoint) {
        try {
            const response = await axiosInstance.delete(endpoint);
            return response.data;
        } catch (error) {
            throw new Error(error.response?.data?.message || 'Network response was not ok');
        }
    },
};
