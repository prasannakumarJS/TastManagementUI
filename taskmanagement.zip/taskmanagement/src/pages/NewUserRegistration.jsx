import { Box, Container, IconButton, InputAdornment, Stack, TextField } from "@mui/material";
import { styled } from "@mui/material/styles";
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import React, { useState } from "react";
import { ApiService } from '../Utils/ApiService';


const StyledRoot = styled('div')(({ theme }) => ({
    [theme.breakpoints.up('md')]: {
        display: 'flex',
        minHeight: '100vh',
        justifyContent: 'center',
        alignItems: 'center',
    }
}))

const Styledsection = styled('div')(({ theme }) => ({
    width: '100%',
    display: 'flex',
    maxHeight: '100vh',
    flexDirection: 'column',
    justifyContent: 'center',
    boxShadow: theme.shadows[12],
    backgroundColor: theme.palette.background.default
}))

const StyledContent = styled('div')(({ theme }) => ({
    margin: 'auto',
    minHeight: '100vh',
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
    width: '90%',
}))
export default function NewUserRegistration() {

    const navigate = useNavigate();

    const [showPassword, setShowPassword] = React.useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setconfirmPassword] = useState('');
    const [firstname, setFirstName] = useState('');
    const [lastname, setLastName] = useState('');
    const [email, setEmial] = useState('');

    const [usernameError, setUsernameError] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const [firstnameError, setFirstNameError] = useState('');
    const [lastnameError, setLastNameError] = useState('');
    const [emailError, setEmailError] = useState('');
    const [confirmPasswordError, setConfirmPasswordError] = useState('');

    const handleCancel = () => {
        navigate('/login');
    }

    const handleRegister = async () => {
        let isValid = true;
        if (!username.trim()) {
            setUsernameError('Username is required');
            isValid = false;
        } else {
            setUsernameError('');
        }

        if (!password.trim()) {
            setPasswordError('Password is required');
            isValid = false;
        } else {
            setPasswordError('');
        }

        if (!confirmPassword.trim()) {
            setConfirmPasswordError('Confirm Password is required');
            isValid = false;
        } else if (password !== confirmPassword) {
            setConfirmPasswordError('Passwords do not match');
            isValid = false;
        } else {
            setConfirmPasswordError('');
        }

        if (!firstname.trim()) {
            setFirstNameError('FirstName is required');
            isValid = false;
        } else {
            setFirstNameError('');
        }

        if (!lastname.trim()) {
            setLastNameError('Lastname is required');
            isValid = false;
        } else {
            setLastNameError('');
        }

        if (!email.trim()) {
            setEmailError('Email is required');
            isValid = false;
        } else {
            setEmailError('');
        }

        if (isValid) {
            // Proceed with authentication logic
            console.log('Username:', username);
            console.log('Password:', password);
            const response = await ApiService.login('https://localhost:7196/api/user/login',
                { username, password, firstName: firstname, lastName: lastname, email, roleType: 1 });
            navigate('/login');
        }
    }

    return (
        <Box alignItems="center" height="100vh" minHeight="100vh">
            <Container maxWidth="sm">
                <StyledRoot>
                    <Styledsection>
                        <StyledContent>
                            <h1>User Registration</h1>
                            <Stack spacing={3}>
                                <TextField id="standard-basic" label="Username" value={username} onChange={(event) => setUsername(event.target.value)} variant="standard" error={!!usernameError}
                                    helperText={usernameError}
                                    required />
                                <TextField id="standard-basic" label="Password" value={password} onChange={(event) => setPassword(event.target.value)} variant="standard"
                                    name="password"
                                    error={!!passwordError}
                                    helperText={passwordError}
                                    required
                                    type={showPassword ? 'text' : 'password'} />
                                <TextField id="standard-basic" label="ConfirmPassword" value={confirmPassword} onChange={(event) => setconfirmPassword(event.target.value)} variant="standard"
                                    name="password"
                                    error={!!confirmPasswordError}
                                    helperText={confirmPasswordError}
                                    required
                                    type={showPassword ? 'text' : 'password'} />
                                <TextField id="standard-basic" label="FirstName" value={firstname} onChange={(event) => setFirstName(event.target.value)} variant="standard" error={!!firstnameError}
                                    helperText={firstnameError}
                                    required />
                                <TextField id="standard-basic" label="LastName" value={lastname} onChange={(event) => setLastName(event.target.value)} variant="standard" error={!!lastnameError}
                                    helperText={lastnameError}
                                    required />
                                <TextField id="standard-basic" label="Email" value={email} onChange={(event) => setEmial(event.target.value)} variant="standard" error={!!emailError}
                                    helperText={emailError}
                                    required />
                                <Button variant="contained" onClick={handleRegister}>Register</Button>
                                <Button variant="outlined" onClick={handleCancel}>Cancel</Button>
                            </Stack>
                        </StyledContent>
                    </Styledsection>
                </StyledRoot>
            </Container>
        </Box>
    )
}