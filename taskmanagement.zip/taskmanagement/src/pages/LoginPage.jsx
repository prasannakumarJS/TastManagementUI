import { Box, Container, IconButton, InputAdornment, Stack, TextField } from "@mui/material";
import { styled } from "@mui/material/styles";
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import React, { useState } from "react";
import axios from "axios";
import { ApiService } from '../Utils/ApiService';


const StyledRoot = styled('div')(({ theme }) => ({
    [theme.breakpoints.up('md')]: {
        display: 'flex',
        minHeight: '100vh',
        justifyContent: 'center',
        alignItems: 'center',
    }
}))

const Styledsection = styled('div')(({ theme }) => ({
    width: '100%',
    display: 'flex',
    maxHeight: '100vh',
    flexDirection: 'column',
    justifyContent: 'center',
    boxShadow: theme.shadows[12],
    backgroundColor: theme.palette.background.default
}))

const StyledContent = styled('div')(({ theme }) => ({
    margin: 'auto',
    minHeight: '70vh',
    display: 'flex',
    justifyContent: 'center',
    flexDirection: 'column',
    width: '90%',
}))
export default function LoginPage() {

    const navigate = useNavigate();

    const [showPassword, setShowPassword] = React.useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [usernameError, setUsernameError] = useState('');
    const [passwordError, setPasswordError] = useState('');

    const handleNewRegistration = () => {
        navigate('/newuser');
    }

    const handleLogin = async () => {
        let isValid = true;
        if (!username.trim()) {
            setUsernameError('Username is required');
            isValid = false;
        } else {
            setUsernameError('');
        }

        if (!password.trim()) {
            setPasswordError('Password is required');
            isValid = false;
        } else {
            setPasswordError('');
        }

        if (isValid) {

            // const response = await axios.post('https://localhost:7196/api/user/login', {
            //     username,
            //     password
            // });
            const response = await ApiService.login('https://localhost:7196/api/user/login', { username, password });
            // Assuming the API returns some token upon successful login
            const token = response;
            // Handle token - e.g., store it in localStorage or Redux store
            console.log('Token:', token);
            console.log('Username:', username);
            console.log('Password:', password);
            navigate('/taskManagement');
        }
    }

    return (
        <Box alignItems="center" height="100vh" minHeight="100vh">
            <Container maxWidth="sm">
                <StyledRoot>
                    <Styledsection>
                        <StyledContent>
                            <h1>Login Page</h1>
                            <Stack spacing={3}>
                                <TextField id="standard-basic" label="Username" value={username} onChange={(event) => setUsername(event.target.value)} variant="standard" error={!!usernameError}
                                    helperText={usernameError}
                                    required />
                                <TextField id="standard-basic" label="Password" value={password} onChange={(event) => setPassword(event.target.value)} variant="standard"
                                    name="password"
                                    error={!!passwordError}
                                    helperText={passwordError}
                                    required
                                    type={showPassword ? 'text' : 'password'} />
                                <Button variant="contained" onClick={handleLogin}>Login</Button>
                                <Button variant="outlined" onClick={handleNewRegistration}>Register</Button>
                            </Stack>
                        </StyledContent>
                    </Styledsection>
                </StyledRoot>
            </Container>
        </Box>
    )
}