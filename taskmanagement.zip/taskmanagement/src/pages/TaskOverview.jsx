import React, { useState, useEffect } from "react";
import { Box, Container, IconButton, InputAdornment, Grid, TextField } from "@mui/material";
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { useNavigate } from 'react-router-dom';
import { ApiService } from '../Utils/ApiService';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

export default function TaskOverview() {
    const navigate = useNavigate();

    const [data, setData] = useState([]);
    const [error, setError] = useState(null);
    const [editMode, setEditMode] = useState(false);
    const [status, setStatus] = useState(1);
    const [task, setTask] = useState({
        title: "",
        description: "",

        completionDate: "",
        createdBy: "",
        userId: "",
    });

    const [taskError, setTaskError] = useState({
        titleError: "",
        descriptionError: "",
        statusError: "",
        completionDateError: "",
        createdByError: "",
        userIdError: "",
    });

    const handleTaskClick = () => {

    }
    const handleCancel = () => {
        setEditMode(false);
    }

    const redirectLogin = () => {
        ApiService.logout();
        navigate('/login');
    }

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await ApiService.get('https://localhost:7011/api/task');
                setData(response);
            } catch (error) {
                setError(error);
            } finally {
            }
        };

        fetchData();
        return () => {
        };
    }, []);


    if (error) {
        return <div>Error: {error.message}</div>;
    }
    var tableHeader = [];
    if (data && data.length > 0) {

        tableHeader = Object.keys(data[0])
        tableHeader.push("Actions")
    }

    const onEditDelete = (actionType, id) => {
        console.log('onEditDelete: ', actionType, id);
        if (actionType === 'edit') {

        }
        else if (actionType === 'delete') {
            setData(data.filter(a => a.id !== id))
        }
    }

    const getActionButtons = (callBack, id) => {
        return <>
            <button onClick={() => callBack('edit', id)}>Edit</button>
            <button onClick={() => callBack('delete', id)}>Delete</button></>
    }
    return (
        <div>
            <AppBar position="static">
                <Toolbar>
                    <Button color="inherit" onClick={() => { setEditMode(!editMode) }}>New Task</Button>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        Task Overview
                    </Typography>
                    <Button color="inherit" onClick={redirectLogin}>Logout</Button>
                </Toolbar>
            </AppBar>
            {!editMode && <div><table>
                <tr>{tableHeader.map(header => <th>{header}</th>)}</tr>
                {
                    data.map(res => <tr>{tableHeader.map(header => header === "Actions" ? getActionButtons(onEditDelete, res["id"]) : <td>{res[header]}</td>)}</tr>)
                }

            </table></div>}
            {editMode &&
                <div>
                    <Grid container spacing={2}>
                        <Grid item xs={8}>
                            <TextField id="standard-basic" label="Title" value={task.title} onChange={(event) => setTask(...task, task.title = event.target.value)} variant="standard" error={!!taskError.titleError}
                                helperText={taskError.titleError}
                                required />
                        </Grid>

                        <Grid item xs={8}>
                            <TextField id="standard-basic" label="Description" value={task.description} onChange={(event) => setTask(...task, task.description = event.target.value)} variant="standard"
                                name="description"
                                error={!!taskError.taskErrordescriptionError}
                                helperText={taskError.taskErrordescriptionError}
                                required
                            />
                        </Grid>
                        <Grid item xs={8}>
                            {/* <TextField id="standard-basic" label="Status" value={task.status} onChange={(event) => setTask(...task, task.status = event.target.value)} variant="standard"
                                name="status"
                                error={!!taskError.statusError}
                                helperText={taskError.statusError}
                                required
                            /> */}
                            <FormControl variant="standard">
                                <InputLabel id="demo-simple-select-standard-label">Age</InputLabel>
                                <Select
                                    labelId="demo-simple-select-standard-label"
                                    id="demo-simple-select-standard"
                                    value={status}
                                    onChange={(event) => setStatus(event.target.value)}
                                    label="Status"
                                >

                                    <MenuItem value={1}>ToDo</MenuItem>
                                    <MenuItem value={2}>InProgress</MenuItem>
                                    <MenuItem value={3}>Completed</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={8}>
                            <TextField id="standard-basic" label="CompletionDate" value={task.completionDate} onChange={(event) => setTask(...task, task.completionDate = event.target.value)} variant="standard" error={!!taskError.completionDateError}
                                helperText={taskError.completionDateError}
                                required />
                        </Grid>
                        <Grid item xs={8}>
                            <TextField id="standard-basic" label="UserId" value={task.userId} onChange={(event) => setTask(...task, task.userId = event.target.value)} variant="standard" error={!!taskError.userIdError}
                                helperText={taskError.userIdError}
                                required />
                        </Grid>
                       
                        <Grid item xs={8}>
                            <Button variant="contained" onClick={handleTaskClick}>Create</Button></Grid>
                        <Grid item xs={8}>
                            <Button variant="outlined" onClick={handleCancel}>Cancel</Button></Grid>
                    </Grid>
                </div>
            }
        </div >
    );
}
