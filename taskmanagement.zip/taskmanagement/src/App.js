import './App.css';
import LoginPage from './pages/LoginPage';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NewUserRegistration from './pages/NewUserRegistration';
import Layout from './layouts/Layout';
import TaskOverview from './pages/TaskOverview';

function App() {
  return (
    <div className="App">
      {/* <LoginPage></LoginPage> */}
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/newuser" element={<NewUserRegistration />} />
            <Route path="/taskManagement" element={<TaskOverview />} />
          </Routes>
        </Layout>
      </Router>
    </div>
  );
}

export default App;
