import React from 'react';
import { Route } from 'react-router-dom';

const Layout = ({ children }) => {
  return (
    <div>
      {/* <Header /> */}
      {children}
    </div>
  );
};

export default Layout;